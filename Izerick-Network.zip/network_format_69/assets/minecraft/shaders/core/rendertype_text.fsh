#version 330
#define HEIGHT_BIT 13
#define MAX_BIT 10
#define ADD_OFFSET 4095
#define DEFAULT_OFFSET 10
#define SHADER_VERSION 3
#moj_import <fog.glsl>
#if SHADER_VERSION >= 3
#moj_import <minecraft:dynamictransforms.glsl>
in float sphericalVertexDistance;in float cylindricalVertexDistance;
#else
uniform vec4 ColorModulator;uniform float FogStart;uniform float FogEnd;uniform vec4 FogColor;in float vertexDistance;
#endif
uniform sampler2D Sampler0;in vec4 vertexColor;in vec2 texCoord0;out vec4 fragColor;in vec4 effectData;
#if SHADER_VERSION >= 3
#moj_import <minecraft:globals.glsl>
#else
uniform float GameTime;
#endif
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0/3.0, 1.0/3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
in vec2 izeBorderPad;
// Original IzeCraft outlines and animated interiors. Runs only for exact style markers.
float izeAlpha(vec2 uv) {
    vec4 glyph = texture(Sampler0, uv);
#ifdef IS_GRAYSCALE
    return glyph.r;
#else
    return glyph.a;
#endif
}
vec3 izeMix(vec3 a, vec3 b, float phase) { return mix(a,b,0.5+0.5*sin(phase)); }
void izeFilledText(inout vec4 color) {
    int id = int(floor(effectData.x + 0.5)) - 100;
    if (id < 17 || id > 26) return;
    vec2 dx = dFdx(effectData.zw), dy = dFdy(effectData.zw);
    vec2 ux = dFdx(texCoord0), uy = dFdy(texCoord0);
    float determinant = dx.x * dy.y - dx.y * dy.x;
    vec2 pixelX = vec2(0.0), pixelY = vec2(0.0);
    if (abs(determinant) > 0.000001) {
        pixelX = (ux * dy.y - uy * dx.y) / determinant;
        pixelY = (uy * dx.x - ux * dy.x) / determinant;
    }
    vec2 uv = texCoord0 + pixelX * izeBorderPad.x + pixelY * izeBorderPad.y;
    float alpha = izeAlpha(uv);
    float coverage = alpha;
    // Four neighbours provide a thin, crisp outline, without a full-screen blur.
    vec2 px = pixelX * 0.60, py = pixelY * 0.60;
    coverage = max(coverage, izeAlpha(uv + px));
    coverage = max(coverage, izeAlpha(uv - px));
    coverage = max(coverage, izeAlpha(uv + py));
    coverage = max(coverage, izeAlpha(uv - py));
    float t = (GameTime <= 1.0) ? GameTime * 1200.0 : GameTime / 20.0;
    vec2 p = effectData.zw + izeBorderPad;
    float phase = p.x * 0.13 - t * 1.5;
    vec3 fill = vec3(1.0), border = vec3(0.055,0.025,0.12);
    if (id == 17) {
        fill = izeMix(vec3(1.0,0.53,0.07),vec3(1.0,0.96,0.56),p.y*0.70+t*1.8);
        fill = mix(fill,vec3(1.0,1.0,0.92),pow(max(0.0,sin(phase+p.y*0.3)),12.0)*0.8);
        border = vec3(0.22,0.065,0.015);
    } else if (id == 18) {
        fill = izeMix(vec3(0.18,0.98,1.0),vec3(1.0,0.27,0.91),phase+sin(p.y*0.8+t*2.0));
        border = vec3(0.15,0.025,0.26);
    } else if (id == 19) {
        float fire = sin(p.x*0.45+sin(p.y*0.85+t*3.0)*1.2-t*2.4);
        fill = izeMix(vec3(1.0,0.20,0.04),vec3(1.0,0.91,0.27),fire*2.3+p.y*0.65);
        border = vec3(0.25,0.025,0.025);
    } else if (id == 20) {
        fill = izeMix(vec3(0.22,1.0,0.69),vec3(0.84,0.47,1.0),phase+sin(p.y*0.4+t));
        border = vec3(0.025,0.11,0.22);
    } else if (id == 21) {
        fill = izeMix(vec3(0.36,0.43,1.0),vec3(0.95,0.49,1.0),phase+p.y*0.55);
        float stars = pow(max(0.0,sin(p.x*1.7+p.y*2.3+t*1.5)),28.0);
        fill = mix(fill,vec3(0.95,1.0,1.0),stars);
        border = vec3(0.055,0.025,0.16);
    } else if (id == 22) {
        float facets = abs(sin(p.x*0.44+p.y*0.75-t*0.9));
        fill = mix(vec3(0.30,0.87,1.0),vec3(0.94,1.0,1.0),facets);
        border = vec3(0.02,0.18,0.25);
    } else if (id == 23) {
        fill = izeMix(vec3(1.0,0.40,0.68),vec3(1.0,0.93,0.97),p.y*0.75+sin(phase)*1.3+t);
        border = vec3(0.26,0.045,0.17);
    } else if (id == 24) {
        float hue = fract(p.x*0.009+p.y*0.027-t*0.055);
        fill = hsv2rgb(vec3(hue,0.62,1.0));
        fill = mix(fill,vec3(1.0),pow(max(0.0,sin(phase+p.y*0.4)),16.0)*0.65);
    } else if (id == 25) {
        float dawn = sin(p.x*0.09-t*1.2+sin(p.y*0.5)*0.45);
        fill = mix(vec3(0.90,0.32,0.03),vec3(1.0,0.93,0.62),smoothstep(-0.5,0.7,dawn));
        float flare = pow(max(0.0,sin(p.x*0.19+p.y*0.11-t*2.2)),20.0);
        fill = mix(fill,vec3(1.0,1.0,0.94),flare*0.85);
        border = vec3(0.25,0.06,0.01);
    } else if (id == 26) {
        float lattice = abs(sin(p.x*0.55+p.y*0.95+t*0.7)*cos(p.x*0.25-p.y*0.65-t*0.9));
        fill = izeMix(vec3(0.57,0.20,0.96),vec3(1.0,0.81,0.30),p.y*0.62+sin(phase*0.7));
        fill = mix(fill,vec3(1.0,0.98,0.92),smoothstep(0.88,1.0,lattice)*0.7);
        border = vec3(0.13,0.025,0.27);
    }
    bool shadow = effectData.y > 0.5;
    vec3 rgb = mix(border, fill, smoothstep(0.10,0.85,alpha));
    color = vec4(rgb * (shadow ? 0.18 : 1.0) * ColorModulator.rgb, coverage * vertexColor.a * ColorModulator.a);
}

void main() {vec4 texColor = texture(Sampler0, texCoord0);vec4 color = texColor * vertexColor * ColorModulator;if (effectData.x >= 0.0 && effectData.y > 0.5) {
                        int effectType = int(effectData.x + 0.5);
                        float speed = effectData.y;
                        float charIndex = effectData.z;
                        float param = effectData.w;
                        float timeSeconds = (GameTime <= 1.0) ? (GameTime * 1200.0) : (GameTime / 20.0);

                            // rainbow (id=0)
                            if (effectType == 0) {
                                float hue = fract(charIndex * 0.03 + timeSeconds * 0.09);
                                color.rgb = hsv2rgb(vec3(hue, 0.9, 1.0));
                            }
                            // wave (id=1)
                            else if (effectType == 1) {
                                color.rgb = vec3(0.333, 0.804, 0.988);
                            }
                            // shake (id=2)
                            else if (effectType == 2) {
                                color.rgb = vec3(1.0, 0.42, 0.42);
                            }
                            // pulse (id=3)
                            else if (effectType == 3) {
                                color.rgb = vec3(1.0, 0.85, 0.24);
                                float pulse = (sin(timeSeconds * 1.5 + charIndex * 0.3) + 1.0) * 0.5;
                                color.a *= 0.3 + pulse * 0.7;
                            }

                    }
izeFilledText(color);
if (color.a < 0.1) {discard;}
#if SHADER_VERSION >= 3
fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#else
fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
#endif
}