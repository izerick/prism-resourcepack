#version 330
#define HEIGHT_BIT 13
#define MAX_BIT 10
#define ADD_OFFSET 4095
#define DEFAULT_OFFSET 10
#define SHADER_VERSION 3
#moj_import <fog.glsl>
#if SHADER_VERSION >= 3
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
out float sphericalVertexDistance;out float cylindricalVertexDistance;
#else
uniform mat4 ProjMat;uniform mat4 ModelViewMat;uniform int FogShape;out float vertexDistance;uniform vec2 ScreenSize;uniform float GameTime;
#endif
in vec3 Position;in vec4 Color;in vec2 UV0;in ivec2 UV2;uniform sampler2D Sampler0;uniform sampler2D Sampler2;uniform vec3 ChunkOffset;out vec4 vertexColor;out vec2 texCoord0;out float applyColor;bool range(float t, float m1, float m2) {return t >= m1 && t <= m2;}bool range(vec2 t, vec2 m1, vec2 m2) {return range(t.x, m1.x, m2.x) && range(t.y, m1.y, m2.y);}bool range(vec3 t, vec3 m1, vec3 m2) {return range(t.x, m1.x, m2.x) && range(t.y, m1.y, m2.y) && range(t.z, m1.z, m2.z);}bool checkElement(float z) {if (z == 0) return true; else if (z == 1000) return true; else if (z == -90) return true; else if (z == 2800) return true; return false;}float fogDistance(vec3 pos, int shape) {if (shape == 0) {return length(pos);} else {float distXZ = length(pos.xz);float distY = abs(pos.y);return max(distXZ, distY);}}out vec4 effectData;
const bool ORAXEN_ANIMATED_GLYPHS = true;
const bool ORAXEN_TEXT_EFFECTS = true;
const int ORAXEN_ANIM_CONFIG_COUNT = 1;
const ivec2 ORAXEN_ANIM_CONFIGS[1] = ivec2[](
    ivec2(16, 16)
);
const int ORAXEN_EFFECT_COUNT = 4;
const ivec3 ORAXEN_EFFECT_TRIGGERS[4] = ivec3[](
    ivec3(253, 13, 0), // rainbow (id=0)
    ivec3(253, 29, 0), // wave (id=1)
    ivec3(253, 45, 0), // shake (id=2)
    ivec3(253, 61, 0) // pulse (id=3)
);
const int ORAXEN_EFFECT_IDS[4] = int[](
    0,
    1,
    2,
    3
);

                

                    
out vec2 izeBorderPad;
#define IZE_VERTEX_INDEX gl_VertexID
// IzeCraft original text styles. Exact RGB markers leave unrelated text/HUD intact.
vec3 izePalette(vec3 a, vec3 b, float phase) {
    return mix(a, b, 0.5 + 0.5 * sin(phase));
}
vec3 izeRainbow(float hue, float saturation) {
    vec3 p = abs(fract(vec3(hue) + vec3(0.0, 2.0/3.0, 1.0/3.0)) * 6.0 - 3.0);
    return mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), saturation);
}
void izeTextStyle(inout vec3 pos, inout vec4 tint) {
    ivec3 raw = ivec3(floor(Color.rgb * 255.0 + 0.5));
    bool shadow = raw.r == 62 && raw.b == 59 && raw.g >= 16 && raw.g <= 41;
    bool primary = raw.r == 251 && raw.b == 239 && raw.g >= 67 && raw.g <= 167 && ((raw.g - 67) % 4 == 0);
    izeBorderPad = vec2(0.0);
    if (!shadow && !primary) return;
    int id = shadow ? raw.g - 15 : (raw.g - 67) / 4 + 1;
    if (id < 1 || id > 26) return;
    bool izeGui = abs(ProjMat[3].x + 1.0) < 0.001;
    // World glyph coordinates are measured in blocks; effects use font pixels.
    vec2 izePoint = izeGui ? pos.xy : (ModelViewMat * vec4(pos, 1.0)).xy * vec2(40.0, -40.0);
    if (id >= 17) {
        effectData = vec4(float(100 + id), shadow ? 1.0 : 0.0, izePoint);
        int corner = IZE_VERTEX_INDEX & 3;
        vec2 direction = vec2(corner < 2 ? -1.0 : 1.0, (corner == 0 || corner == 3) ? -1.0 : 1.0);
        izeBorderPad = direction * 0.65;
        if (izeGui) pos.xy += izeBorderPad;
        else pos += inverse(mat3(ModelViewMat)) * vec3(izeBorderPad * vec2(0.025, -0.025), 0.0);
        tint.rgb = vec3(1.0);
        return;
    }
    float t = (GameTime <= 1.0) ? GameTime * 1200.0 : GameTime / 20.0;
    float x = izePoint.x - (shadow ? 1.0 : 0.0);
    float phase = x * 0.095 - t * 1.65;
    float wave = sin(x * 0.24 - t * 3.2);
    float shiftY = 0.0;
    float shiftX = 0.0;
    vec3 c = vec3(1.0);
    if (id == 1) { c = izeRainbow(x * 0.012 - t * 0.085, 0.57); shiftY = wave * 0.95; }
    else if (id == 2) { c = izePalette(vec3(1.0,0.40,0.90),vec3(0.30,0.94,1.0),phase); }
    else if (id == 3) { c = izePalette(vec3(0.12,0.80,1.0),vec3(0.80,1.0,1.0),phase); c = mix(c,vec3(1.0),pow(max(0.0,sin(t*9.0+x*0.4)),18.0)*0.8); }
    else if (id == 4) { c = izePalette(vec3(1.0,0.19,0.08),vec3(1.0,0.87,0.20),x*0.16+t*2.7); shiftY = sin(x*0.31+t*5.0)*0.25; }
    else if (id == 5) { c = izePalette(vec3(0.69,0.36,1.0),vec3(1.0,0.84,0.44),phase*0.72); }
    else if (id == 6) { c = mix(vec3(1.0,0.69,0.12),vec3(1.0,1.0,0.87),pow(max(0.0,sin(phase)),7.0)); }
    else if (id == 7) { c = izePalette(vec3(0.34,0.73,1.0),vec3(0.88,1.0,1.0),phase); shiftY = wave*0.48; }
    else if (id == 8) { c = izePalette(vec3(0.22,0.91,0.48),vec3(0.76,1.0,0.81),phase); c *= 0.88+0.12*sin(t*2.0); }
    else if (id == 9) { c = izePalette(vec3(0.45,0.44,1.0),vec3(0.95,0.44,1.0),phase*0.8); c = mix(c,vec3(0.95,1.0,1.0),pow(max(0.0,sin(x*0.47+t*2.4)),22.0)*0.75); }
    else if (id == 10) { c = izePalette(vec3(1.0,0.22,0.39),vec3(1.0,0.64,0.81),t*2.8); }
    else if (id == 11) { c = izePalette(vec3(0.13,0.62,1.0),vec3(0.29,1.0,0.86),phase); shiftY = wave*0.68; }
    else if (id == 12) { c = izePalette(vec3(1.0,0.20,0.91),vec3(0.14,0.99,1.0),phase*1.6); c = mix(c,vec3(1.0),pow(max(0.0,sin(phase*0.5)),14.0)*0.45); }
    else if (id == 13) { c = izePalette(vec3(0.64,0.42,0.94),vec3(0.88,0.92,1.0),phase*0.65); }
    else if (id == 14) { c = izePalette(vec3(1.0,0.44,0.57),vec3(1.0,0.86,0.30),phase); c = mix(c,vec3(1.0,1.0,0.90),pow(max(0.0,sin(phase*0.7)),12.0)*0.7); }
    else if (id == 15) { c = izePalette(vec3(0.25,1.0,0.84),vec3(0.77,0.49,1.0),phase*2.0); float hit=step(0.96,sin(floor(t*12.0)*4.73)); shiftX=sin(x*0.8+t*13.0)*0.45*hit; }
    else if (id == 16) { c = izePalette(vec3(1.0,0.76,0.26),vec3(1.0,0.94,0.66),phase*0.7); shiftY=sin(t*2.0+x*0.10)*0.65; }
    if (izeGui) { pos.x += shiftX; pos.y += shiftY; }
    else pos += inverse(mat3(ModelViewMat)) * vec3(shiftX * 0.025, -shiftY * 0.025, 0.0);
    tint.rgb = c * (shadow ? 0.22 : 1.0);
}

void main() {vec3 pos = Position;vec2 ui = ceil(2 / vec2(ProjMat[0][0], -ProjMat[1][1]));vec2 uiScreen = ui / ScreenSize;vec3 color = Color.xyz;applyColor = 0;vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);if (pos.y >= ui.y && ProjMat[3].x == -1) {int bit = int(pos.y) >> HEIGHT_BIT;if (((bit >> MAX_BIT) & 1) == 1) {int id = bit - (1 << MAX_BIT);pos.x -= 0.5 * ui.x;pos.y -= (bit << HEIGHT_BIT) + ADD_OFFSET + DEFAULT_OFFSET;float xGui = 0;float yGui = 0;float layer = 0;float opacity = 1;bool outline = false;int property = 0;switch (id) {case 1:xGui = ui.x * 8.0 / 100.0;yGui = ui.y * 1.0 / 100.0;break;case 2:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 1.0 / 100.0;layer = -1;break;case 3:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 1.0 / 100.0;outline = true;break;case 4:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 100.0 / 100.0;layer = 1;break;case 5:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 100.0 / 100.0;layer = 2;break;case 6:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 100.0 / 100.0;layer = 3;outline = true;break;}
#if SHADER_VERSION < 2
vertexColor = (checkElement(pos.z) && !outline) ? vec4(0) : Color * texelFetch(Sampler2, UV2 / 16, 0) * vec4(1, 1, 1, opacity);
#else
vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0) * vec4(1, 1, 1, opacity);
#endif
if ((property & 1) > 0) {pos.y += 4 * sin((GameTime * 1200 + pos.x / ui.x) * 3.1415 * 2);}if ((property & 2) > 0) {int hash = int(pos.x) * int(pos.y);float time = GameTime * 1200;hash = 31 * (hash + int(vertexColor.x + time));float r = float(hash % 224 + 32) / 255;hash = 31 * (hash + int(vertexColor.y + time));float g = float(hash % 224 + 32) / 255;hash = 31 * (hash + int(vertexColor.z + time));float b = float(hash % 224 + 32) / 255;float maxValue = max(max(r, g), b);vertexColor = vec4(pow(r / maxValue, 3), pow(g / maxValue, 3), pow(b / maxValue, 3), vertexColor.w);}if ((property & 4) > 0) {int hash = int(pos.x) * int(pos.y);float time = GameTime * 1200;hash = 31 * (hash + int(vertexColor.x + time));float r = vertexColor.x + float(hash % 64) / 255;hash = 31 * (hash + int(vertexColor.y + time));float g = vertexColor.y + float(hash % 64) / 255;hash = 31 * (hash + int(vertexColor.z + time));float b = vertexColor.z + float(hash % 64) / 255;vertexColor = vec4(r, g, b, vertexColor.w);}pos.x += xGui;pos.y += yGui;pos.z += layer;}} else {vec3 exp = vec3(128.0, 255.0, 32.0);if (ProjMat[3].x == -1 && range(pos.y, ui.y - 60, ui.y - 20) && range(pos.x, ui.x / 2 - 60, ui.x / 2 + 60) && (range(color, exp / 256, exp / 254) || color == vec3(0))) {vertexColor = vec4(0);}}
effectData = vec4(-1.0,0.0,0.0,0.0);
int rInt = int(Color.r * 255.0 + 0.5);
                        int gRaw = int(Color.g * 255.0 + 0.5);
                        int bRaw = int(Color.b * 255.0 + 0.5);

                        // Check for animation color on the primary pass only.
                        //
                        // Shadow-pass colors are normal text colors divided by 4, so trying
                        // to detect animated shadow colors by RGB range causes many false
                        // positives (e.g. vanilla white text shadow 63,63,63). That makes
                        // regular text render without shadow. We intentionally only detect
                        // the primary animation marker here to keep vanilla shadows intact.
                        //
                        // A red value of 254 can occur in regular RGB gradients. To avoid
                        // treating those characters as animated glyphs, require the encoded
                        // FPS/loop and frame-count tuple to match an actually generated
                        // animated glyph, and require the frame index to be valid.
                        bool isPrimaryAnim = false;
                        if (ORAXEN_ANIMATED_GLYPHS && ORAXEN_ANIM_CONFIG_COUNT > 0 && rInt == 254) {
                            int candidateFrameIndex = bRaw & 0x0F;
                            int candidateTotalFrames = ((bRaw >> 4) & 0x0F) + 1;
                            if (candidateFrameIndex < candidateTotalFrames) {
                                for (int i = 0; i < ORAXEN_ANIM_CONFIG_COUNT; i++) {
                                    if (gRaw == ORAXEN_ANIM_CONFIGS[i].x && candidateTotalFrames == ORAXEN_ANIM_CONFIGS[i].y) {
                                        isPrimaryAnim = true;
                                        break;
                                    }
                                }
                            }
                        }

                        if (ORAXEN_ANIMATED_GLYPHS && isPrimaryAnim) {
                            int gInt = gRaw;
                            int bInt = bRaw;

                            bool loop = (gInt < 128);
                            float fps = max(1.0, float(gInt & 0x7F));
                            int frameIndex = bInt & 0x0F;
                            int totalFrames = ((bInt >> 4) & 0x0F) + 1;

                            float timeSeconds = (GameTime <= 1.0) ? (GameTime * 1200.0) : (GameTime / 20.0);
                            int rawFrame = int(floor(timeSeconds * fps));
                            int currentFrame = loop ? int(mod(float(rawFrame), float(totalFrames))) : min(rawFrame, totalFrames - 1);

                            float visible = (frameIndex == currentFrame && isPrimaryAnim) ? 1.0 : 0.0;

                            vertexColor = vec4(1.0, 1.0, 1.0, visible) * texelFetch(Sampler2, UV2 / 16, 0);
                        }

                        // Text effects: exact trigger color matching
                        if (ORAXEN_TEXT_EFFECTS && ORAXEN_EFFECT_COUNT > 0 && (!ORAXEN_ANIMATED_GLYPHS || !isPrimaryAnim)) {
                            // Check for exact trigger color match
                            ivec3 colorInt = ivec3(rInt, gRaw, bRaw);
                            int effectType = -1;
                            for (int i = 0; i < ORAXEN_EFFECT_COUNT; i++) {
                                if (colorInt == ORAXEN_EFFECT_TRIGGERS[i]) {
                                    effectType = ORAXEN_EFFECT_IDS[i];
                                    break;
                                }
                            }

                            if (effectType >= 0) {
                                float speed = 3.0; // Default speed (configured in shader snippets)
                                float param = 3.0; // Default param (configured in shader snippets)
                                float charIndex = float(gl_VertexID >> 2);

                                float timeSeconds = (GameTime <= 1.0) ? (GameTime * 1200.0) : (GameTime / 20.0);

                            // wave (id=1)
                            if (effectType == 1) {
                                float phase = charIndex * 0.6 + timeSeconds * 6.0;
                                pos.y += sin(phase) * 2.0;
                            }
                            // shake (id=2)
                            else if (effectType == 2) {
                                float seed = charIndex + floor(timeSeconds * 32.0);
                                pos.x += (fract(sin(seed * 12.9898) * 43758.5453) - 0.5) * 1.5;
                                pos.y += (fract(sin(seed * 78.233) * 43758.5453) - 0.5) * 1.5;
                            }


                                
                            

                                // Pass effect data to fragment shader
                                effectData = vec4(float(effectType), speed, charIndex, param);
                            }
                        }
#if SHADER_VERSION >= 3
sphericalVertexDistance = fog_spherical_distance(pos);cylindricalVertexDistance = fog_cylindrical_distance(pos);
#else
vertexDistance = fogDistance(pos, FogShape);
#endif
texCoord0 = UV0;gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
  izeTextStyle(pos, vertexColor);
  gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
}