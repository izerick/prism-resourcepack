#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
    float LineWidth;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec4 Color;

out vec4 vertexColor;
out float networkHeaderMask;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;
    bool headerColor = all(lessThan(abs(Color.rgb), vec3(0.001))) && abs(Color.a - 128.0/255.0) < 0.001;
    vec4 screenPosition = ModelViewMat * vec4(Position, 1.0);
    bool headerEdge = abs(screenPosition.y - 9.0) < 0.001 || abs(screenPosition.y - 64.0) < 0.001;
    networkHeaderMask = headerColor && headerEdge ? 1.0 : 0.0;

}
