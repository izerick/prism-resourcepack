#version 330
#extension GL_ARB_separate_shader_objects : require

#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#include <minecraft:light.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

#include <minecraft:sample_lightmap.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
layout(location = 5) in vec3 Normal;

uniform sampler2D Sampler0;
#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler1;
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler2;
#endif

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
layout(location = 2) out vec4 vertexPerFaceColorBack;
layout(location = 3) out vec4 vertexPerFaceColorFront;
#else
layout(location = 2) out vec4 vertexColor;
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
layout(location = 4) out vec4 lightMapColor;
#endif

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
layout(location = 5) out vec4 overlayColor;
#endif

layout(location = 6) out vec2 texCoord0;
#ifdef GLINT
layout(location = 7) out vec2 texCoordGlint;
#endif

layout(location = 8) flat out vec4 tint;
layout(location = 9) flat out vec3 vNormal;
layout(location = 10) out vec2 origTexCoord0;
layout(location = 11) flat out int isTopLayer;
layout(location = 12) flat out int isHead;
layout(location = 13) out float vGameTime;

#define VANILLA_SKIN_TEX_SIZE 64.
#define BONE_TEX_SIZE 16.
#define BONE_TEX_SIZE_NORM BONE_TEX_SIZE / VANILLA_SKIN_TEX_SIZE
#define PER_BONE_VTXS 24
#define PER_BONE_VTXS_BOTH_LAYERS 48

#define IS_NOT_GUI ProjMat[3][2] != -2.
#define MIGHT_BE_TOP_LAYER UV0.x > 0.5
#define b1 gl_VertexIndex % 12

#define handle_top_layer(index) if (a2 == index && MIGHT_BE_TOP_LAYER) isTopLayer = 1;

#define NIGHT_COLOR normalize(vec3(42.0 / 255.0, 42.0 / 255.0, 72.0 / 255.0))
#define DAY_COLOR normalize(vec3(1.0, 1.0, 1.0))
float qq1(sampler2D lightMap) {
    vec3 sunLight = texture(lightMap, vec2(0.5 / 16.0, 15.5 / 16.0)).rgb;
    float sunLightLength = length(sunLight);
    if (sunLightLength == 0.0) return 0.0;
    sunLight /= sunLightLength;
    return clamp(pow(length(sunLight -  NIGHT_COLOR) / length(DAY_COLOR -  NIGHT_COLOR), 4.0), 0.0, 1.0);
}

layout(location = 14) flat out vec4 izeSkinData;
#include <minecraft:globals.glsl>

void main() {
    izeSkinData=vec4(0.0);
    if(all(equal(textureSize(Sampler0,0),ivec2(64,64)))) {
        ivec3 m0=ivec3(floor(texelFetch(Sampler0,ivec2(0,0),0).rgb*255.0+0.5));
        ivec3 m1=ivec3(floor(texelFetch(Sampler0,ivec2(1,0),0).rgb*255.0+0.5));
        ivec3 m2=ivec3(floor(texelFetch(Sampler0,ivec2(2,0),0).rgb*255.0+0.5));
        ivec3 m3=ivec3(floor(texelFetch(Sampler0,ivec2(3,0),0).rgb*255.0+0.5));
        if(all(equal(m0,ivec3(73,90,69)))&&all(equal(m1,ivec3(83,75,78)))&&all(equal(m2,ivec3(23,10,19)))&&m3.r>=1&&m3.r<=4&&m3.b==255)
            izeSkinData=vec4(float(m3.r),GameTime,float(m3.g),0.0);
    }

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
    lightMapColor = sample_lightmap(Sampler2, UV2);
#endif

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;
#ifdef GLINT
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif
#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

    isTopLayer = 0;
    isHead = 0;
    origTexCoord0 = UV0;
    vNormal = Normal;
    tint = Color;
    vGameTime = GameTime;
    if(vGameTime <= 0) {
        vGameTime = 0.5;
    }

    // IzeCraft 26.3: ordinary players, NPCs and marked effect skins all use
    // native geometry and UVs. The retired ItemsAdder emote remapper assumed
    // fixed per-bone vertex indices, which no longer identify RenderPearl batches.
    // The native body effect is RGB-only and remains in the fragment shader.

}