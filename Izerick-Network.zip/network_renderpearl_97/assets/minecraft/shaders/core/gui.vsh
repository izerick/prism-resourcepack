#version 330
#extension GL_ARB_separate_shader_objects : require

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;

layout(location = 0) out vec4 vertexColor;
layout(location = 1) out float networkHeaderMask;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;
    bool headerColor = all(lessThan(abs(Color.rgb), vec3(0.001))) && abs(Color.a - 128.0/255.0) < 0.001;
    vec4 screenPosition = ModelViewMat * vec4(Position, 1.0);
    bool headerEdge = abs(screenPosition.y - 9.0) < 0.001 || abs(screenPosition.y - 64.0) < 0.001;
    networkHeaderMask = headerColor && headerEdge ? 1.0 : 0.0;

}
