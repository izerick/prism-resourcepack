                #version 330
#extension GL_ARB_separate_shader_objects : require

                #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)
#include <minecraft:fog.glsl>
#endif
                #include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
                #include <minecraft:globals.glsl>

                uniform sampler2D Sampler0;

                layout(location = 0) in float sphericalVertexDistance;
                layout(location = 1) in float cylindricalVertexDistance;
                layout(location = 2) in vec4 vertexColor;
                layout(location = 3) in vec2 texCoord0;
                layout(location = 4) in vec4 effectData;

                #ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

                // HSV to RGB conversion for rainbow effect
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0/3.0, 1.0/3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

                vec4 oraxen_sample_text() {
                    vec4 texel = texture(Sampler0, texCoord0);
                #ifdef IS_GRAYSCALE
                    return texel.rrrr;
                #else
                    return texel;
                #endif
                }

                
vec4 networkTextColor(vec4 color) {
#ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
#endif
#if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)
#ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
#else
    vec4 fogColor = FogColor;
#endif
    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
#endif
    return color;
}

void main() {
                    vec4 color = oraxen_sample_text() * vertexColor * ColorModulator;
                    vec4 texColor = color;

                    // Apply text effects if effectData.x >= 0 (effectType, 0 is rainbow)
                    if (effectData.x >= 0.0 && effectData.y > 0.5) {
                        int effectType = int(effectData.x + 0.5);
                        float speed = effectData.y;
                        float charIndex = effectData.z;
                        float param = effectData.w;
                        float timeSeconds = (GameTime <= 1.0) ? (GameTime * 1200.0) : (GameTime / 20.0);

                            // rainbow (id=0)
                            if (effectType == 0) {
                                float hue = fract(charIndex * 0.03 + timeSeconds * 0.09);
                                texColor.rgb = hsv2rgb(vec3(hue, 0.9, 1.0));
                            }
                            // wave (id=1)
                            else if (effectType == 1) {
                                texColor.rgb = vec3(0.333, 0.804, 0.988);
                            }
                            // shake (id=2)
                            else if (effectType == 2) {
                                texColor.rgb = vec3(1.0, 0.42, 0.42);
                            }
                            // pulse (id=3)
                            else if (effectType == 3) {
                                texColor.rgb = vec3(1.0, 0.85, 0.24);
                                float pulse = (sin(timeSeconds * 1.5 + charIndex * 0.3) + 1.0) * 0.5;
                                texColor.a *= 0.3 + pulse * 0.7;
                            }

                    }

                    color = texColor;

                    if (color.a < 0.1) {
                        discard;
                    }

#ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
#else
    fragColor = networkTextColor(color);
#endif
                }
