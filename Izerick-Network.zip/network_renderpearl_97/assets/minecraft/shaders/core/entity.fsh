#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#if defined(NO_OVERLAY) && defined(ALPHA_CUTOUT) && !defined(EMISSIVE)
#include <minecraft:light.glsl>
#endif
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#ifdef GLINT
#include <minecraft:globals.glsl>
uniform sampler2D GlintSampler;
layout(location = 7) in vec2 texCoordGlint;
#endif

//%START_CUSTOM_ARMORS_VARS%
#define V1 16
#define V2 50
#define TEX_WIDTH 128
#define TEX_HEIGHT 32
//%END_CUSTOM_ARMORS_VARS%

uniform sampler2D Sampler0;

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
layout(location = 2) in vec4 vertexPerFaceColorBack;
layout(location = 3) in vec4 vertexPerFaceColorFront;
#else
layout(location = 2) in vec4 vertexColor;
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
layout(location = 4) in vec4 lightMapColor;
#endif

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
layout(location = 5) in vec4 overlayColor;
#endif

layout(location = 6) in vec2 texCoord0;

layout(location = 8) flat in vec4 tint;
layout(location = 9) flat in vec3 vNormal;
layout(location = 10) in vec2 origTexCoord0;
layout(location = 11) flat in int isTopLayer;
layout(location = 12) flat in int isHead;
layout(location = 13) in float vGameTime;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif


#if defined(NO_OVERLAY) && defined(ALPHA_CUTOUT) && !defined(EMISSIVE)
vec4 networkArmorLighting() {
#ifdef OIT_ALPHA_ONLY
    return vec4(1.0);
#else
    return minecraft_mix_light(Light0_Direction, Light1_Direction, vNormal, vec4(1.0)) * lightMapColor;
#endif
}
#endif

void networkOutputColor(vec4 color) {
#ifdef GLINT
    color.a = max(color.a, GlintAlpha);
#endif
#ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
#else
#ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    color.rgb += glintColor.rgb * glintColor.rgb;
#endif
#ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
#else
    vec4 fogColor = FogColor;
#endif
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
#endif
}

layout(location = 14) in vec4 izeVfxData;
// IzeCraft body surfaces. Only four exact data-texture colors opt in.
float izeVfxHash(vec2 p) {return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float izeVfxNoise(vec2 p) {
    vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);
    return mix(mix(izeVfxHash(i),izeVfxHash(i+vec2(1,0)),f.x),mix(izeVfxHash(i+vec2(0,1)),izeVfxHash(i+vec2(1,1)),f.x),f.y);
}
vec4 izeBodySurface(vec4 original) {
    ivec3 rgb=ivec3(floor(original.rgb*255.0+0.5));
    if(rgb.r!=246 || rgb.b!=237 || rgb.g<45 || rgb.g>165 || (rgb.g-45)%40!=0)return original;
    if(!gl_FrontFacing) discard;
    int style=(rgb.g-45)/40+1;
    float t=izeVfxData.w<=1.0?izeVfxData.w*1200.0:izeVfxData.w/20.0;
    vec2 p=texCoord0*vec2(textureSize(Sampler0,0));
    vec3 color;float alpha;
    if(style==1) {
        float flow=izeVfxNoise(p*vec2(0.36,0.20)+vec2(0.0,t*0.85));
        float stream=0.5+0.5*sin(p.x*0.82+flow*5.5-p.y*0.26-t*1.8);
        float fire=smoothstep(0.67,0.98,stream);
        float core=pow(fire,4.0);
        color=mix(vec3(1.0,0.19,0.025),vec3(1.0,0.83,0.21),fire);
        color=mix(color,vec3(1.0,0.98,0.79),core*0.88);
        alpha=fire*0.90;
    } else if(style==2) {
        float scan=pow(0.5+0.5*sin(p.y*3.14159-t*6.0),10.0);
        float circuit=pow(1.0-abs(sin(p.x*0.72+floor(p.y*0.28)*1.4)),13.0);
        float sweep=pow(0.5+0.5*sin(p.y*0.27-t*2.0),18.0);
        color=mix(vec3(0.12,0.72,1.0),vec3(0.72,1.0,1.0),max(sweep,circuit));
        alpha=min(0.78,scan*0.38+circuit*0.45+sweep*0.42);
    } else if(style==3) {
        float n=izeVfxNoise(p*0.22+vec2(t*0.12,-t*0.18));
        float ribbon=pow(0.5+0.5*sin(p.x*0.36+p.y*0.65+n*4.0-t*1.3),9.0);
        float star=pow(max(0.0,sin(p.x*3.7+p.y*2.4+t*1.2)),52.0)*pow(izeVfxNoise(floor(p*1.8)),5.0);
        color=mix(vec3(0.37,0.11,0.92),vec3(0.94,0.43,1.0),ribbon);
        color=mix(color,vec3(0.80,1.0,1.0),min(1.0,star*7.0));
        alpha=min(0.88,ribbon*0.66+star*3.0);
    } else {
        float bend=sin(p.y*0.82+floor(t*9.0)*1.7)*1.6+sin(p.y*1.7-t*2.4)*0.6;
        float arc=pow(1.0-abs(sin(p.x*0.63+bend)),20.0);
        float pulse=0.65+0.35*sin(t*11.0+p.y*0.22);
        color=mix(vec3(0.04,0.73,1.0),vec3(0.91,1.0,1.0),arc);
        alpha=arc*pulse*0.92;
    }
    // Keep the original player visible through the cosmetic shell.
    if(alpha*original.a<0.10) discard;
    return vec4(color,alpha*original.a);
}

void main() {
#ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
#else
    vec4 faceVertexColor = vertexColor;
#endif

    //%START_CUSTOM_ARMORS%
#if defined(NO_OVERLAY) && defined(ALPHA_CUTOUT) && !defined(EMISSIVE)
    if(tint != vec4(0)) {
        ivec2 atlasSize = textureSize(Sampler0, 0);
        if(atlasSize == ivec2(TEX_WIDTH, TEX_HEIGHT) && atlasSize.x > 7 && atlasSize.y > 7) {
            int armorAmount = atlasSize.x / (V1 * 4);
            float armorColumns = float(armorAmount);
            float maxFrames = atlasSize.y / (V1 * 2.0);
            vec2 coords = texCoord0;
            coords.x /= armorColumns;
            coords.y /= maxFrames;
            if (texelFetch(Sampler0, ivec2(0, 1), 0) == vec4(1)
                    && texelFetch(Sampler0, ivec2(7, 7), 0) == vec4(0)) {
                vec4 textureProperties = vec4(0);
                vec4 customColor = vec4(0);
                float h_offset = 1.0 / armorColumns;
                vec2 nextFrame = coords;
                float interpolClock = 0;
                vec4 vtc = faceVertexColor;
                for (int i = 1; i < armorAmount; i++) {
                    customColor = texelFetch(Sampler0, ivec2(V1 * 4 * i + 0.5, 0), 0);
                    if (tint == customColor) {
                        coords.x += (h_offset * i);
                        vec4 animInfo = texelFetch(Sampler0, ivec2(V1 * 4 * i + 1.5, 0), 0);
                        animInfo.rgb *= animInfo.a * 255;
                        textureProperties = texelFetch(Sampler0, ivec2(V1 * 4 * i + 2.5, 0), 0);
                        textureProperties.rgb *= textureProperties.a * 255;
                        if (animInfo.r > 0.0) {
                            float timer = floor(mod(vGameTime * V2 * animInfo.g, animInfo.r));
                            if (animInfo.b > 0) interpolClock = fract(vGameTime * V2 * animInfo.g);
                            float v_offset = (V1 * 2.0) / atlasSize.y * timer;
                            nextFrame = coords;
                            coords.y += v_offset;
                            nextFrame.y += (V1 * 2.0) / atlasSize.y * mod(timer + 1, animInfo.r);
                        }
                        break;
                    }
                }
                if (textureProperties.g == 1) {
                    if (textureProperties.r > 1) {
                        vtc = tint;
                    } else if (textureProperties.r == 1) {
                        if (texture(Sampler0, vec2(coords.x + h_offset, coords.y)).a != 0) {
                            vtc = tint * texture(Sampler0, vec2(coords.x + h_offset, coords.y)).a;
                        }
                    }
                } else if (textureProperties.g == 0) {
                    if (textureProperties.r > 1) {
                        vtc = vec4(1);
                    } else if (textureProperties.r == 1) {
                        if (texture(Sampler0, vec2(coords.x + h_offset, coords.y)).a != 0) {
                            vtc = vec4(1) * texture(Sampler0, vec2(coords.x + h_offset, coords.y)).a;
                        } else {
                            vtc = networkArmorLighting();
                        }
                    } else {
                        vtc = networkArmorLighting();
                    }
                } else {
                    vtc = networkArmorLighting();
                }
                vec4 armor = mix(texture(Sampler0, coords), texture(Sampler0, nextFrame), interpolClock);
                vec4 color;
                if (coords.x < (1.0 / armorColumns))
                    color = armor * faceVertexColor * ColorModulator;
                else
                    color = armor * vtc * ColorModulator;

                if (color.a < 0.1) discard;
                networkOutputColor(color);
                return;
            }
        }
    }
#endif
    //%END_CUSTOM_ARMORS%

    if (isHead == 1 && gl_FrontFacing == false) discard;

    vec2 UV = texCoord0;
    if (isTopLayer == 1 || origTexCoord0.y >= 0.25)
        UV = origTexCoord0;

    vec4 color = izeBodySurface(texture(Sampler0, UV));
#ifdef OIT_ADDITIVE
    color.a = min(0.99, color.a);
#endif
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

#ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, UV).a) {
        discard;
    }
    // The dissolve effect entirely replaces translucency
    faceVertexColor.a = 1.0;
#endif

    color *= faceVertexColor * ColorModulator;
#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
    color *= lightMapColor;
#endif

    networkOutputColor(color);
}