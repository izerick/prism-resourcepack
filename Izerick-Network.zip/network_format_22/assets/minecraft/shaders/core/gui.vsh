#version 150

in vec3 Position;
in vec4 Color;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec4 vertexColor;
out float networkHeaderMask;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;
    bool headerColor = all(lessThan(abs(Color.rgb), vec3(0.001))) && abs(Color.a - 128.0/255.0) < 0.001;
    vec4 screenPosition = ModelViewMat * vec4(Position, 1.0);
    bool headerEdge = abs(screenPosition.y - 9.0) < 0.001 || abs(screenPosition.y - 64.0) < 0.001;
    networkHeaderMask = headerColor && headerEdge ? 1.0 : 0.0;

}
