#version 150

in vec4 vertexColor;
in float networkHeaderMask;

uniform vec4 ColorModulator;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor;
    if (networkHeaderMask > 0.9999) discard;
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
