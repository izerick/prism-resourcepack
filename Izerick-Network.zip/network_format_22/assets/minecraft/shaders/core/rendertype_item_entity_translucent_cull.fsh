#version 150

#moj_import <fog.glsl>

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;
in vec4 normal;

out vec4 fragColor;

in vec4 izeVfxData;
// IzeCraft body surfaces. Only four exact data-texture colors opt in.
float izeVfxHash(vec2 p) {return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float izeVfxNoise(vec2 p) {
    vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);
    return mix(mix(izeVfxHash(i),izeVfxHash(i+vec2(1,0)),f.x),mix(izeVfxHash(i+vec2(0,1)),izeVfxHash(i+vec2(1,1)),f.x),f.y);
}
vec4 izeBodySurface(vec4 original) {
    ivec3 rgb=ivec3(floor(original.rgb*255.0+0.5));
    if(rgb.r!=246 || rgb.b!=237 || rgb.g<45 || rgb.g>165 || (rgb.g-45)%40!=0)return original;
    if(!gl_FrontFacing) discard;
    int style=(rgb.g-45)/40+1;
    float t=izeVfxData.w<=1.0?izeVfxData.w*1200.0:izeVfxData.w/20.0;
    vec2 p=texCoord0*vec2(textureSize(Sampler0,0));
    vec3 color;float alpha;
    if(style==1) {
        float flow=izeVfxNoise(p*vec2(0.36,0.20)+vec2(0.0,t*0.85));
        float stream=0.5+0.5*sin(p.x*0.82+flow*5.5-p.y*0.26-t*1.8);
        float fire=smoothstep(0.67,0.98,stream);
        float core=pow(fire,4.0);
        color=mix(vec3(1.0,0.19,0.025),vec3(1.0,0.83,0.21),fire);
        color=mix(color,vec3(1.0,0.98,0.79),core*0.88);
        alpha=fire*0.90;
    } else if(style==2) {
        float scan=pow(0.5+0.5*sin(p.y*3.14159-t*6.0),10.0);
        float circuit=pow(1.0-abs(sin(p.x*0.72+floor(p.y*0.28)*1.4)),13.0);
        float sweep=pow(0.5+0.5*sin(p.y*0.27-t*2.0),18.0);
        color=mix(vec3(0.12,0.72,1.0),vec3(0.72,1.0,1.0),max(sweep,circuit));
        alpha=min(0.78,scan*0.38+circuit*0.45+sweep*0.42);
    } else if(style==3) {
        float n=izeVfxNoise(p*0.22+vec2(t*0.12,-t*0.18));
        float ribbon=pow(0.5+0.5*sin(p.x*0.36+p.y*0.65+n*4.0-t*1.3),9.0);
        float star=pow(max(0.0,sin(p.x*3.7+p.y*2.4+t*1.2)),52.0)*pow(izeVfxNoise(floor(p*1.8)),5.0);
        color=mix(vec3(0.37,0.11,0.92),vec3(0.94,0.43,1.0),ribbon);
        color=mix(color,vec3(0.80,1.0,1.0),min(1.0,star*7.0));
        alpha=min(0.88,ribbon*0.66+star*3.0);
    } else {
        float bend=sin(p.y*0.82+floor(t*9.0)*1.7)*1.6+sin(p.y*1.7-t*2.4)*0.6;
        float arc=pow(1.0-abs(sin(p.x*0.63+bend)),20.0);
        float pulse=0.65+0.35*sin(t*11.0+p.y*0.22);
        color=mix(vec3(0.04,0.73,1.0),vec3(0.91,1.0,1.0),arc);
        alpha=arc*pulse*0.92;
    }
    // Keep the original player visible through the cosmetic shell.
    if(alpha*original.a<0.10) discard;
    return vec4(color,alpha*original.a);
}

void main() {
    vec4 color = izeBodySurface(texture(Sampler0, texCoord0)) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
