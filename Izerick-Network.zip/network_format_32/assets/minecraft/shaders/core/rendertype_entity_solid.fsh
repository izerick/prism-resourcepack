#version 150

#moj_import <fog.glsl>

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;

out vec4 fragColor;

flat in vec4 izeSkinData;
// Native player skin only. RGB animation preserves geometry, skin alpha and UVs.
float izeSkinHash(vec2 p) {return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453);}
float izeSkinNoise(vec2 p) {
    vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);
    return mix(mix(izeSkinHash(i),izeSkinHash(i+vec2(1,0)),f.x),
               mix(izeSkinHash(i+vec2(0,1)),izeSkinHash(i+vec2(1,1)),f.x),f.y);
}
vec4 izeNativeSkin(vec4 original) {
    if(izeSkinData.x<0.5)return original;
    float t=izeSkinData.y<=1.0?izeSkinData.y*1200.0:izeSkinData.y/20.0;
    vec2 p=texCoord0*64.0;
    // The face stays recognizable. The head sides/back can still carry energy.
    bool face=(p.x>=8.0&&p.x<16.0&&p.y>=8.0&&p.y<16.0)
           ||(p.x>=40.0&&p.x<48.0&&p.y>=8.0&&p.y<16.0);
    float intensity=face?0.18:1.0;
    vec3 energy=original.rgb;float amount=0.0;
    if(izeSkinData.x<1.5) {
        float n=izeSkinNoise(p*vec2(0.40,0.21)+vec2(0,t*1.2));
        float n2=izeSkinNoise(p*0.77+vec2(t*0.15,t*1.8));
        float wave=0.5+0.5*sin(p.x*0.85+n*5.8-p.y*0.30-t*2.4);
        float fire=smoothstep(0.62,0.95,wave+n2*0.13);
        float core=smoothstep(0.83,1.0,fire);
        energy=mix(vec3(1.0,0.12,0.015),vec3(1.0,0.63,0.04),fire);
        energy=mix(energy,vec3(1.0,0.98,0.70),core*0.82);
        amount=fire*0.88;
    } else if(izeSkinData.x<2.5) {
        float scan=pow(0.5+0.5*sin(p.y*3.14159-t*5.0),8.0);
        float circuit=1.0-smoothstep(0.06,0.18,abs(sin(p.x*0.64+floor(p.y*0.25)*1.3)));
        float sweep=pow(0.5+0.5*sin(p.y*0.24-t*2.1),16.0);
        energy=mix(vec3(0.02,0.52,1.0),vec3(0.67,1.0,1.0),max(circuit,sweep));
        amount=min(0.78,scan*0.22+circuit*0.40+sweep*0.47);
    } else if(izeSkinData.x<3.5) {
        float n=izeSkinNoise(p*0.24+vec2(t*0.18,-t*0.13));
        float ribbon=pow(0.5+0.5*sin(p.x*0.43+p.y*0.38+n*4.8-t*1.4),7.0);
        vec2 cell=floor(p*0.65);vec2 point=fract(p*0.65)-0.5;
        float star=(1.0-smoothstep(0.04,0.15,length(point)))*step(0.91,izeSkinHash(cell));
        star*=0.35+0.65*pow(0.5+0.5*sin(t*3.0+izeSkinHash(cell)*30.0),3.0);
        energy=mix(vec3(0.29,0.04,0.75),vec3(0.85,0.29,1.0),ribbon);
        energy=mix(energy,vec3(0.8,1.0,1.0),min(1.0,star*2.5));
        amount=min(0.85,ribbon*0.67+star*0.9);
    } else {
        float phase=floor(t*9.0);
        float bend=sin(p.y*0.83+phase*1.7)*1.4+sin(p.y*1.65-phase*0.7)*0.7;
        float line=abs(sin(p.x*0.59+bend));
        float aa=max(fwidth(line)*0.7,0.025);
        float glow=1.0-smoothstep(0.08,0.33,line);
        float core=1.0-smoothstep(0.02,0.06+aa,line);
        energy=mix(vec3(0.01,0.53,1.0),vec3(0.90,1.0,1.0),core);
        float pulse=0.74+0.26*sin(t*13.0+p.y*0.2);
        amount=min(0.98,(glow*0.32+core*0.86)*pulse);
    }
    return vec4(mix(original.rgb,energy,amount*intensity),original.a);
}

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;
    fragColor = linear_fog(izeNativeSkin(color), vertexDistance, FogStart, FogEnd, FogColor);
}
