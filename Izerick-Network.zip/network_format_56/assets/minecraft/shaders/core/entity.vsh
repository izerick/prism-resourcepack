#version 150

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;
out vec2 texCoord0;

flat out vec4 izeSkinData;
uniform sampler2D Sampler0;
#moj_import <minecraft:globals.glsl>

void main() {
    izeSkinData=vec4(0.0);
    if(all(equal(textureSize(Sampler0,0),ivec2(64,64)))) {
        ivec3 m0=ivec3(floor(texelFetch(Sampler0,ivec2(0,0),0).rgb*255.0+0.5));
        ivec3 m1=ivec3(floor(texelFetch(Sampler0,ivec2(1,0),0).rgb*255.0+0.5));
        ivec3 m2=ivec3(floor(texelFetch(Sampler0,ivec2(2,0),0).rgb*255.0+0.5));
        ivec3 m3=ivec3(floor(texelFetch(Sampler0,ivec2(3,0),0).rgb*255.0+0.5));
        if(all(equal(m0,ivec3(73,90,69)))&&all(equal(m1,ivec3(83,75,78)))&&all(equal(m2,ivec3(23,10,19)))&&m3.r>=1&&m3.r<=4&&m3.b==255)
            izeSkinData=vec4(float(m3.r),GameTime,float(m3.g),0.0);
    }

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
#ifdef NO_CARDINAL_LIGHTING
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif
#ifndef EMISSIVE
    lightMapColor = texelFetch(Sampler2, UV2 / 16, 0);
#endif
    overlayColor = texelFetch(Sampler1, UV1, 0);

    texCoord0 = UV0;
#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif
}
